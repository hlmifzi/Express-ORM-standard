import {
	PemasukanBarang,
	ReturBarang,
	PenjualanBarang,
	PenyusutanBarang,
	BarangType,
	Stok
} from "../../model/index"
import ApiResponse from "../../utils/apiResponse"

const addPemasukanBarang = async (req, res) => {
	try {
		// get stok barang type
		let barangType = await BarangType.findByPk(req.body.barang_type_id, {
			include: { model: Stok }
		})
		
		// akumulasi stok
		let totalStok = barangType.stoks[0].jumlah + req.body.jumlah
		
		// update & insert transaction
		let data = await PemasukanBarang.create(req.body)		
		let updateStok = await Stok.update({ jumlah: totalStok }, { where: { barang_type_id: req.body.barang_type_id } })

		// response
		let response = {
			transaction: req.body,
			stokBefore: barangType.stoks[0].jumlah,
			stokAfter: totalStok
		}
		ApiResponse.ok(res, 'Add pemasukan barang success', response)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const addReturBarang = async (req, res) => {
	try {
		// get stok barang type
		let barangType = await BarangType.findByPk(req.body.barang_type_id, {
			include: { model: Stok }
		})

		// validate stok
		if (barangType.stoks[0].jumlah < req.body.jumlah) {
			return ApiResponse.badRequest(res, 'Add retur barang gagal, jumlah transaksi melebihi stok')
		}

		// akumulasi stok
		let totalStok = barangType.stoks[0].jumlah - req.body.jumlah

		// update & insert transaction
		let updateStok = await Stok.update({ jumlah: totalStok }, { where: { barang_type_id: req.body.barang_type_id } })
		let data = await ReturBarang.create(req.body)

		// response
		let response = {
			transaction: req.body,
			stokBefore: barangType.stoks[0].jumlah,
			stokAfter: totalStok
		}
		ApiResponse.ok(res, 'Add retur barang success', response)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const addPenjualanBarang = async (req, res) => {
	try {
		// get stok barang type
		let barangType = await BarangType.findByPk(req.body.barang_type_id, {
			include: { model: Stok }
		})

		// validate stok
		if (barangType.stoks[0].jumlah < req.body.jumlah) {
			return ApiResponse.badRequest(res, 'Add penjualan barang gagal, jumlah transaksi melebihi stok')
		}

		// akumulasi stok
		let totalStok = barangType.stoks[0].jumlah - req.body.jumlah
		
		// update & insert transaction
		let updateStok = await Stok.update({ jumlah: totalStok }, { where: { barang_type_id: req.body.barang_type_id } })
		let data = await PenjualanBarang.create(req.body)

		// response
		let response = {
			transaction: req.body,
			stokBefore: barangType.stoks[0].jumlah,
			stokAfter: totalStok
		}
		ApiResponse.ok(res, 'Add penjualan barang success', response)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const addPenyusutanBarang = async (req, res) => {
	try {
		// get stok barang type
		let barangType = await BarangType.findByPk(req.body.barang_type_id, {
			include: { model: Stok }
		})

		// get stok barang type normal
		let barangTypeOb = await BarangType.findOne({ 
			where: { barang_id: barangType.barang_id, type: 'OB'}, 
			include: { model: Stok }
		})
		
		// validate stok
		if (barangType.stoks[0].jumlah < req.body.jumlah) {
			return ApiResponse.badRequest(res, 'Add penyusutan barang gagal, jumlah transaksi melebihi stok')
		}

		// withdraw stok
		let stokNormal = barangType.stoks[0].jumlah - req.body.jumlah 
		let stokOb = barangTypeOb.stoks[0].jumlah + req.body.jumlah
		
		// update & insert transaction
		let updateStok = await Stok.update({ jumlah: stokNormal }, { where: { barang_type_id: barangType.barang_type_id } })
		let updateStokOb = await Stok.update({ jumlah: stokOb }, { where: { barang_type_id: barangTypeOb.barang_type_id } })
		let data = await PenyusutanBarang.create(req.body)

		// response
		let response = {
			transaction: req.body,
			stokNormal: stokNormal,
			stokOb: stokOb
		}
		ApiResponse.ok(res, 'Add penyusutan barang success', response)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

export { addPemasukanBarang, addReturBarang, addPenjualanBarang, addPenyusutanBarang }