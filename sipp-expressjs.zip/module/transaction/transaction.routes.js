import express from "express"
import validate from "express-validation"

import { addPemasukanBarang, addReturBarang, addPenjualanBarang, addPenyusutanBarang } from "./transaction.controller"
import transactionValidation from "../../middleware/validation/transaction.validation"

const router = express.Router()

router.post('/addPemasukanBarang', validate(transactionValidation.addPemasukanBarang), addPemasukanBarang)
router.post('/addReturBarang', validate(transactionValidation.addReturBarang), addReturBarang)
router.post('/addPenjualanBarang', validate(transactionValidation.addPenjualanBarang), addPenjualanBarang)
router.post('/addPenyusutanBarang', validate(transactionValidation.addPenyusutanBarang), addPenyusutanBarang)

export default router