import Sequelize from "sequelize"
const Op = Sequelize.Op;

import { PemasukanBarang, ReturBarang, PenjualanBarang, PenyusutanBarang, Place, BarangType } from "../../model/index"
import ApiResponse from "../../utils/apiResponse"

const getAllPemasukan = async (req, res) => {
	// let test = req.body.barang_type_id ?  req.body.barang_type_id : null
	// console.log(test)
	try {
		// let c2 = req.body.barang_type_id ? { barang_type_id: req.body.barang_type_id } : null
		let condition = {}
		condition.active = 1
		if (req.body.barang_type_id) { condition.barang_type_id = req.body.barang_type_id }
		if (req.body.date_from) { condition.created_at = { [Op.gt]: new Date(req.body.date_from) } }
		if (req.body.date_to) { condition.created_at = { [Op.lt]: new Date(req.body.date_to) } }
		if (req.body.date_from && req.body.date_to) { condition.created_at = { [Op.gt]: new Date(req.body.date_from), [Op.lt]: new Date(req.body.date_to) } }

		let data = await PemasukanBarang.findAll({
			include: [
				{ 
					model: BarangType,
					attributes: ['barang_type_id', 'type', 'harga']
				},
				{ 
					model: Place,
					as: 'place_froms',
					attributes: ['place_id', 'name']
				},
				{ 
					model: Place,
					as: 'place_tos',
					attributes: ['place_id', 'name']
				}
			],
			where: condition,
			attributes: ['jumlah', 'barang_type_id', 'pemasukan_barang_id', 'place_from', 'place_to', 'created_at']
		})
		ApiResponse.ok(res, 'Get all pemasukan success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const getAllRetur = async (req, res) => {
	try {
		let condition = {}
		condition.active = 1
		if (req.body.barang_type_id) { condition.barang_type_id = req.body.barang_type_id }
		if (req.body.date_from) { condition.created_at = { [Op.gt]: new Date(req.body.date_from) } }
		if (req.body.date_to) { condition.created_at = { [Op.lt]: new Date(req.body.date_to) } }
		if (req.body.date_from && req.body.date_to) { condition.created_at = { [Op.gt]: new Date(req.body.date_from), [Op.lt]: new Date(req.body.date_to) } }
		let data = await ReturBarang.findAll({
			include: [
				{ 
					model: BarangType,
					attributes: ['barang_type_id', 'type', 'harga']
				},
				{ 
					model: Place,
					as: 'place_froms',
					attributes: ['place_id', 'name']
				},
				{ 
					model: Place,
					as: 'place_tos',
					attributes: ['place_id', 'name']
				}
			],
			where: condition,
			attributes: ['jumlah', 'barang_type_id', 'retur_barang_id', 'place_from', 'place_to', 'created_at']
		})
		ApiResponse.ok(res, 'Get all retur success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const getAllPenjualan = async (req, res) => {
	try {
		let condition = {}
		condition.active = 1
		if (req.body.barang_type_id) { condition.barang_type_id = req.body.barang_type_id }
		if (req.body.date_from) { condition.created_at = { [Op.gt]: new Date(req.body.date_from) } }
		if (req.body.date_to) { condition.created_at = { [Op.lt]: new Date(req.body.date_to) } }
		if (req.body.date_from && req.body.date_to) { condition.created_at = { [Op.gt]: new Date(req.body.date_from), [Op.lt]: new Date(req.body.date_to) } }
		let data = await PenjualanBarang.findAll({
			include: [
				{ 
					model: BarangType,
					attributes: ['barang_type_id', 'type', 'harga']
				},
				{ 
					model: Place,
					as: 'place_froms',
					attributes: ['place_id', 'name']
				},
				{ 
					model: Place,
					as: 'place_tos',
					attributes: ['place_id', 'name']
				}
			],
			where: condition,
			attributes: ['jumlah', 'barang_type_id', 'penjualan_barang_id', 'place_from', 'place_to', 'created_at']
		})
		ApiResponse.ok(res, 'Get all penjualan success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const getAllPenyusutan = async (req, res) => {
	try {
		let condition = {}
		condition.active = 1
		if (req.body.barang_type_id) { condition.barang_type_id = req.body.barang_type_id }
		if (req.body.date_from) { condition.created_at = { [Op.gt]: new Date(req.body.date_from) } }
		if (req.body.date_to) { condition.created_at = { [Op.lt]: new Date(req.body.date_to) } }
		if (req.body.date_from && req.body.date_to) { condition.created_at = { [Op.gt]: new Date(req.body.date_from), [Op.lt]: new Date(req.body.date_to) } }
		let data = await PenyusutanBarang.findAll({
			include: [
				{ 
					model: BarangType,
					attributes: ['barang_type_id', 'type', 'harga']
				},
				{ 
					model: Place,
					as: 'place_froms',
					attributes: ['place_id', 'name']
				},
				{ 
					model: Place,
					as: 'place_tos',
					attributes: ['place_id', 'name']
				}
			],
			where: condition,
			attributes: ['jumlah', 'barang_type_id', 'penyusutan_barang_id', 'place_from', 'place_to', 'created_at']
		})
		ApiResponse.ok(res, 'Get all penyusutan success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const excPemasukan = async (req, res) => {
	try {
		let data = await PemasukanBarang.findAll()
		ApiResponse.ok(res, 'Get all  success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}
const excRetur = async (req, res) => {
	try {
		let data = await ReturBarang.findAll()
		ApiResponse.ok(res, 'Get all  success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}
const excPenjualan = async (req, res) => {
	try {
		let data = await PenjualanBarang.findAll()
		ApiResponse.ok(res, 'Get all  success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}
const excPenyusutan = async (req, res) => {
	try {
		let data = await PenyusutanBarang.findAll()
		ApiResponse.ok(res, 'Get all  success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}


export { getAllPemasukan, getAllRetur, getAllPenjualan, getAllPenyusutan, excPemasukan, excRetur, excPenjualan, excPenyusutan }