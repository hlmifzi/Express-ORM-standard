import { Barang, BarangType, Stok, Place } from "../../model/index"
import ApiResponse from "../../utils/apiResponse"

const addBarang = async (req, res) => {
	try {
		let data = req.body
		let dataBarang = await Barang.create(data)
		var dataBarangType = await BarangType.create({barang_id: dataBarang.barang_id, type: "NORMAL", harga: req.body.harga_normal })
		// var dataStok = await Stok.create({ barang_type_id: dataBarangType.barang_type_id })
		var dataBarangType = await BarangType.create({barang_id: dataBarang.barang_id, type: "OB", harga: req.body.harga_ob })
		// var dataStok = await Stok.create({ barang_type_id: dataBarangType.barang_type_id })
        
		ApiResponse.created(res, 'Add barang success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const getAllBarang = async (req, res) => {
	try {
		let data = await Barang.findAll({
			include: [
				{ 
					model: BarangType,
					include: [
						{ 
							model: Stok,
							include: [
								{
									model: Place,
									attributes: ['place_id', 'name']
								}
							],
							attributes: ['stok_id', 'jumlah']
						}
					],
					attributes: ['barang_type_id', 'type', 'harga']
				}
			],
			where: { active: 1 },
			attributes: ['artikel', 'size', 'warna', 'barang_id', 'nama_barang']
		})
		ApiResponse.ok(res, 'Get all barang success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const getBarangByID = async (req, res) => {
	try {
		let data = await Barang.findOne({
			include: [
				{ 
					model: BarangType,
					include: [
						{ 
							model: Stok,
							include: [
								{
									model: Place,
									attributes: ['place_id', 'name']
								}
							],
							attributes: ['stok_id', 'jumlah']
						}
					],
					attributes: ['barang_type_id', 'type', 'harga']
				}
			],
			where: { active: 1, barang_id: req.params.id },
			attributes: ['artikel', 'size', 'warna', 'barang_id', 'nama_barang']
		
		})
		ApiResponse.ok(res, 'Get all barang success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const updateBarang = async (req, res) => {
	try {
		let data = req.body
		let dataBarang = await Barang.update({ nama: data.nama, size: data.size, warna: data.warna }, { where : { barang_id : data.barang_id } })
		
		let nbarang_type_id = await BarangType.findOne({
			where: { barang_id: data.barang_id, type: "NORMAL" },
			attributes: ['barang_type_id']
		})
		let nBarangType = await BarangType.update({ harga: data.harga_normal }, { where : { barang_type_id: nbarang_type_id.barang_type_id } })

		
		let obarang_type_id = await BarangType.findOne({
			where: { barang_id: data.barang_id, type: "OB" },
			attributes: ['barang_type_id']
		})
		let oBarangType = await BarangType.update({ harga: data.harga_ob }, { where : { barang_type_id: obarang_type_id.barang_type_id } })

		ApiResponse.ok(res, 'Updated barang success', dataBarang)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

const deleteBarang = async (req, res) => {
	try {
		let data = Barang.update({ "active":0 }, { where : { barang_id: req.body.barang_id } })
		ApiResponse.ok(res, 'Deleted barang success', data)
	} catch (err) {
		ApiResponse.internalServerError(res, 'Internal server error', err)
	}
}

export { addBarang, getAllBarang, getBarangByID, updateBarang, deleteBarang }