import Joi from "joi"

export default {
    getAllPemasukan: {
        body: {
            barang_type_id: Joi.number(),
            date_from: Joi.date(),
            date_to: Joi.date()
        }
    },
    getAllRetur: {
        body: {
            barang_type_id: Joi.number(),
            date_from: Joi.date(),
            date_to: Joi.date()
        }
    },
    getAllPenjualan: {
        body: {
            barang_type_id: Joi.number(),
            date_from: Joi.date(),
            date_to: Joi.date()
        }
    },
    getAllPenyusutan: {
        body: {
            barang_type_id: Joi.number(),
            date_from: Joi.date(),
            date_to: Joi.date()
        }
    },
}