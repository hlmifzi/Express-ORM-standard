import Joi from "joi"

export default {
    addPemasukanBarang: {
        body: {
            pemasukan_barang_id: Joi.number().required(),
            barang_type_id: Joi.number().required(),
            place_from: Joi.number().required(),
            place_to: Joi.number().required(),
            jumlah: Joi.number().required(),
            created_by: Joi.number().required()
        }
    },
    addReturBarang: {
        body: {
            pemasukan_barang_id: Joi.number().required(),
            barang_type_id: Joi.number().required(),
            place_from: Joi.number().required(),
            place_to: Joi.number().required(),
            jumlah: Joi.number().required(),
            created_by: Joi.number().required()
        }
    },
    addPenjualanBarang: {
        body: {
            pemasukan_barang_id: Joi.number().required(),
            barang_type_id: Joi.number().required(),
            place_from: Joi.number().required(),
            jumlah: Joi.number().required(),
            created_by: Joi.number().required()
        }
    },
    addPenyusutanBarang: {
        body: {
            pemasukan_barang_id: Joi.number().required(),
            barang_type_id: Joi.number().required(),
            place_from: Joi.number().required(),
            jumlah: Joi.number().required(),
            created_by: Joi.number().required()
        }
    }
}